#pragma once

#define dfCLIENT_WIDTH 800
#define dfCLIENT_HEIGHT 600

