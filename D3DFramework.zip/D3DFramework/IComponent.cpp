#include "stdafx.h"
#include "IComponent.h"

using namespace PKH;

PKH::IComponent::IComponent()
{
}

PKH::IComponent::IComponent(const PKH::IComponent & rhs)
{
}

PKH::IComponent::~IComponent()
{
}

void PKH::IComponent::Update()
{
}
