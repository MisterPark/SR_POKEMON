#include "stdafx.h"
#include "PlayerCharacter.h"

PlayerCharacter::PlayerCharacter()
{
	
}

PlayerCharacter::~PlayerCharacter()
{
}

void PlayerCharacter::Initialize()
{
}

void PlayerCharacter::Update()
{
	Character::Update();
}

void PlayerCharacter::Render()
{
	Character::Render();
}

void PlayerCharacter::Release()
{
}

void PlayerCharacter::Attack(const Vector3 & dir)
{
}

void PlayerCharacter::Skill(const Vector3 & dir)
{
}