#pragma once
#include "Mesh.h"

namespace PKH
{
	class Plane :
		public Mesh
	{
	public:
		Plane();
		virtual ~Plane();

	};
}


