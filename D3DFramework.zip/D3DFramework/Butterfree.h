#pragma once
#include "Monster.h"
class Butterfree :
    public Monster
{
public:
    Butterfree();
    virtual ~Butterfree();


};

